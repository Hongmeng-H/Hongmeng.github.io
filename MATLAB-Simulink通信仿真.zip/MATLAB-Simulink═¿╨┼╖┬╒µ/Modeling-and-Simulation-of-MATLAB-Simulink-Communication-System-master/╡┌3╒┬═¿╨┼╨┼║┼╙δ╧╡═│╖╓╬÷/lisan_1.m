t=0:0.1:2*pi;
x=cos(2*t);
stem(t,x)