clear all;
k = -50:50;
X =  0.25*sinc(k/4);
stem(k,X);
