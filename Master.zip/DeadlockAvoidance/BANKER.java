package DeadlockAvoidance;

import java.util.*;
import java.io.*;
import java.lang.*;

class BANKER {
	public static void main(String[] args) {
		int ab,res,r,c,e;
		System.out.println("输入进程数和可用资源种类数：");
		Scanner sc = new Scanner(System.in);
		ab = sc.nextInt();
		res = sc.nextInt();
		
		int[][] Allocation = new int[ab][res];
		int[][] Max = new int[ab][res];
		int[][] Need = new int[ab][res];
		int[] Available = new int[res];
		int[] alloc_avail = new int[res];		//可用资源数
		
		System.out.println("输入已分配资源矩阵：");
		for(r=0;r<ab;r++) for(c=0;c<res;c++) Allocation[r][c] = sc.nextInt();
		
		System.out.println("输入最大资源需求矩阵：");
		for(r=0;r<ab;r++) for(c=0;c<res;c++) Max[r][c] = sc.nextInt();	
		
		System.out.println("输入可用资源矩阵：");
		for(r=0;r<res;r++) Available[r] = sc.nextInt();
		
		System.out.println("需求矩阵为：");
		for(r=0;r<ab;r++) {
			for(c=0;c<res;c++) {
				Need[r][c] = Max[r][c] - Allocation[r][c];
				System.out.print(Need[r][c]+" ");
			}
			System.out.println();
		}
		
		for(r=0;r<res;r++) {
			for(c=0;c<ab;c++) {
				alloc_avail[r]+=Allocation[c][r];
			}
			alloc_avail[r]+=Available[r];
		}

		int[] process_complete = new int[ab];
		int[] unsafe_chk = new int[ab];
		int tnp = ab,ip=0,f=0;
		
		for(r=0;r<ab;r++) {
			for(c=0;c<res;c++) {
				if(alloc_avail[c]<Need[r][c]) {
					f=1;
					System.out.println("Unsafe");
				}
			}
		}
		if(f==0){
		while(true) {
			f=0;
			if(ip==ab) ip=0;
			if(unsafe_chk[ip]==1 && tnp<=1) {
				f=1;
				break;
			}
			if(process_complete[ip] == 1) {
				ip++;
				continue;
			} else {
				for(c=0;c<res;c++) {
					if(Available[c]<Need[ip][c]) f=1;
				}
				if(f==1) {
					for(c=0;c<res;c++) {
						if(alloc_avail[c]<Need[ip][c]) unsafe_chk[ip]=1;
					}
					ip++;
					continue;
				} else {
					process_complete[ip]=1;
					System.out.println("进程"+ip+"可以分配资源..");
					System.out.println("进程终止,释放资源..");
					System.out.println("释放后可用的资源有：");
					for(c=0;c<res;c++) {
						Available[c] += Allocation[ip][c];
						System.out.print(Available[c]+" ");
					}
					System.out.println("\n");
					ip++;
					tnp--;
					if(tnp==0) break;
				}
			}
		}
		}
		if(tnp==0) System.out.println("Safe");
		//else if(f==1) System.out.println("Unsafe");
	}
}
