package PageSwap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * READ:主要写的是OPT,FIFO算法自不必说，简单
 * 而LRU也是根据OPT小改而来,仅向前倒序排列得到淘汰序列
 * OPT注释较全为保留所有思考的痕迹,而LRU全部精简
 *
 *   !!!!主要看OPT!!!!
 */

public class PageSwap {
    static int PageFrameSize = 3;       //物理块大小
    static List<Integer> PageFrame = new ArrayList<>();        //页框
    static List<Integer> list = new ArrayList<>();       //list存储
    static int[] PageSequence = new int[PageFrameSize];         //访问页面序列
    static int X80 = 0;                //调用0X80缺页中断次数
    static int Request = 0;                //请求指针

    /**
     * 初始化Lis和PageF
     */
    static void createList(int[]a){
        for (int i : a)
            list.add(i);
    }

    /**
     * OPT
     */
    static void OPT(int []pageSequence){
            //  int OUT[] = new int[pageSequence.length-PageFrame.length];      //淘汰队列(确定谁调出) ,最大为请求长度减框
            List<Integer> OUT = new ArrayList<>();
            List<Integer> listOut = new ArrayList<>();       //获得Request后的元素并创建新集合，为后面查询做准备
            int OutPage;

            while (true){
                //  !asList(PageFrame).contains(PageSequence[Request]))           //请求页面不在物理块才调页
                if (PageFrame.size() != PageFrameSize&&!PageFrame.contains(PageSequence[Request])) {       //请求未占满页框   请求调页一次就产生一次缺页中断
                    X80++;                         //缺页中断，请求调页
                    PageFrame.add(list.get(Request));     //调页
                    Request++;                    //处理下次请求
                    for (int e :                //测试输出
                            PageFrame) {
                        System.out.println(e);
                    }
                    System.out.println("---------------");


                    if (Request - 1 == pageSequence.length)
                        break;                      //  !!!!!!!!!!处理82行可能出现的异常，见标记(处理请求序列小于页框)

                } else if (PageFrame.size() == PageFrameSize&&!PageFrame.contains(PageSequence[Request])){                             //页框(物理块)满,先确定淘汰页面再换入
                    for (int i = Request + 1; i <= list.size() - 1; i++) {
                        listOut.add(list.get(i));
                    }

//                for (int e=Request+1;e<pageSequence.length;e++) {        //从请求指针下一个开始遍历确定淘汰页面(拿到序号，有-1先淘汰，没有则按索引顺序淘汰最大的)
//                    OUT[e] = list.get(pageSequence[e-Request-1]);        //得到淘汰队列
//                }
                    for (int e = Request + 1, i = 0; e <= pageSequence.length && i < PageFrame.size(); e++, i++) {        //!!!!重要 用Request+1后续进行遍历 (此处当页框遍历完时或当访问序列遍历完时才会停止，此处要保证页框必须大于访问序列)
                        OUT.add(listOut.indexOf(PageFrame.get(i)));
                    }

//                    OUT.indexOf(-1);
//                    Collections.max(OUT);
//                    OUT.indexOf(Collections.max(OUT));

                    if (OUT.contains(-1)) {                  //有以后不会访问元素时
                        OutPage = OUT.indexOf(-1);
                    } else {                                //没有则找第一次访问索引最大项
                        OutPage = OUT.indexOf(Collections.max(OUT));
                    }
                    X80++;
                    System.out.println("第" + Request + "页到来时淘汰的是:  " + OutPage);
                    PageFrame.set(OutPage, list.get(Request));       //调页


                    for (int e :                //测试输出
                            PageFrame) {
                        System.out.println(e);
                    }
                    System.out.println("---------------");

                    Request++;              //处理下次请求
                    if (Request == PageSequence.length)
                        break;

                    OUT.clear();
                    //Arrays.fill(OUT,0);  //同下
                    listOut.clear();        //清除所有,避免新new,节约空间

                }else {         //页框内页面请求调入,请求指针后移
                    Request++;
                    if (Request == PageSequence.length) {
                        break;
                    }
                }

            }

    }



    /**
     * FIFO
     */
    static void FIFO(){
        int Old = 0;            //指向在内存驻留最久的页面，等价于栈底指针
        while (true){
            //  !asList(PageFrame).contains(PageSequence[Request]))           //请求页面不在物理块才调页
            if (PageFrame.size() != PageFrameSize&&!PageFrame.contains(PageSequence[Request])) {       //请求未占满页框   请求调页一次就产生一次缺页中断,此时Old指针不移哦
                X80++;                         //缺页中断，请求调页
                PageFrame.add(list.get(Request));     //调页
                Request++;                    //处理下次请求
                for (int e :                //测试输出
                        PageFrame) {
                    System.out.println(e);
                }
                System.out.println("---------------");

                if (Request - 1 == PageSequence.length)
                    break;
            } else if (PageFrame.size() == PageFrameSize&&!PageFrame.contains(PageSequence[Request])){      //页框(物理块)满,先确定淘汰页面再换入
                X80++;                         //缺页中断，请求调页
                System.out.println("第" + Request + "页到来时淘汰的是:  " + PageFrame.get(Old));
                PageFrame.set(Old,list.get(Request));       //调页
                Old++;                              //Old指针后移
                if (Old == PageFrameSize){        //若Old指向最后，重新将其置为0
                    Old = 0;
                }
                Request++;

                for (int e :                //测试输出
                        PageFrame) {
                    System.out.println(e);
                }
                System.out.println("---------------");

                if (Request == PageSequence.length) {
                    break;
                }
            }else {         //页框内页面请求调入,请求指针后移
                Request++;
                if (Request == PageSequence.length) {
                    break;
                }
            }

        }
    }

    /**
     * LRU
     */
    static void LRU(int []pageSequence){
        List<Integer> OUT = new ArrayList<>();
        List<Integer> listOut = new ArrayList<>();
        int OutPage;
        while (true){
            if (PageFrame.size() != PageFrameSize&&!PageFrame.contains(PageSequence[Request])) {       //请求未占满页框   请求调页一次就产生一次缺页中断
                X80++;                         //缺页中断，请求调页
                PageFrame.add(list.get(Request));     //调页
                Request++;                    //处理下次请求
                for (int e :                //测试输出
                        PageFrame) {
                    System.out.println(e);
                }
                System.out.println("---------------");

                if (Request - 1 == pageSequence.length) break;    //  !!!!!!!!!!处理82行可能出现的异常，见标记(处理请求序列小于页框)
            } else if (PageFrame.size() == PageFrameSize&&!PageFrame.contains(PageSequence[Request])){                             //页框(物理块)满,先确定淘汰页面再换入
                for (int i = Request - 1; i >= 0; i--)
                    listOut.add(list.get(i));
                for (int e = Request - 1, i = 0; e >= 0 && i < PageFrame.size(); e--, i++)        //!!!!重要 用Request+1后续进行遍历 (此处当页框遍历完时或当访问序列遍历完时才会停止，此处要保证页框必须大于访问序列)
                    OUT.add(listOut.indexOf(PageFrame.get(i)));

                if (OUT.contains(-1)) {                  //有以后不会访问元素时
                    OutPage = OUT.indexOf(-1);
                } else {                                //没有则找第一次访问索引最大项
                    OutPage = OUT.indexOf(Collections.max(OUT));
                }
                X80++;
                System.out.println("第" + Request + "页到来时淘汰的是:  " + OutPage);
                PageFrame.set(OutPage, list.get(Request));       //调页
                for (int e :                //测试输出
                        PageFrame) {
                    System.out.println(e);
                }
                System.out.println("---------------");

                Request++;              //处理下次请求
                if (Request == PageSequence.length)
                    break;

                OUT.clear();
                //Arrays.fill(OUT,0);  //同下
                listOut.clear();        //清除所有,避免新new,节约空间

            }else {         //页框内页面请求调入,请求指针后移
                Request++;
                if (Request == PageSequence.length) {
                    break;
                }
            }

        }
    }


    public static void main(String[] args) {
        PageSequence = new int[]{7,0,1,2,0,3,0,4,2,3,0,3,2,1,2,0,1,7,0,1};
        createList(PageSequence);
        OPT(PageSequence);
       //LRU(PageSequence);
       // FIFO();
        System.out.println("缺页次数:"+X80);
        System.out.println("缺页率:"+X80*1.0/list.size());
    }

}
