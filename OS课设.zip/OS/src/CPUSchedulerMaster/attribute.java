package CPUSchedulerMaster;

public class attribute {
    static  int runname=-1;//给当前进度起名字
    int Run_time;//需要运行时间
    int input_time;//输入时间
    int name=-1;//进程序号
    public  int getName() {
        return name;
    }
    public  void setName(int name) {
        this.name = name;
    }
    public attribute() {
    }
    public attribute( int input_time,int run_time) {
        this.Run_time = run_time;
        this.input_time = input_time;
        runname++;
        this.name=runname+0;

    }
    public int getRun_time() {
        return Run_time;
    }
    public void setRun_time(int run_time) {
        Run_time = run_time;
    }
    public int getInput_time() {
        return input_time;
    }
    public void setInput_time(int input_time) {
        this.input_time = input_time;
    }
}

