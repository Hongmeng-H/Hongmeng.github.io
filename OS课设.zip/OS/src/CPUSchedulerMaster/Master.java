package CPUSchedulerMaster;
import java.util.Scanner;
public class Master {
    public static void OutputAttribute(attribute[] ab) {        //输出进程
        int  time=ab[0].input_time;
        for (int i=0;i<ab.length;i++){
            if (ab[i].input_time>time){
                time=ab[i].input_time;
            }
            System.out.print("到达时间"+time+" ");
            time+=ab[i].Run_time;
            System.out.print("运行时间"+ab[i].Run_time+" ");
            System.out.print("运行进程为"+ab[i].name+" ");
            System.out.print("周转时间为"+(time-ab[i].input_time)+" ");
            System.out.println();
        }
    }
    public static void runattribute(attribute[] ab) {//运行调用
        System.out.println("请选择排序方式");
        Scanner in=new Scanner(System.in);
        int n=-1;
        while (n!=0){
            System.out.println("1,先来先服务  2,短作业优先  3,RP级排序 ,0退出");
            n=in.nextInt();
            switch (n){
                case  1:  ab=InputTimesort(ab);OutputAttribute(ab);break;
                case  2:  ab=Short_jobs_take_precedence(ab,0,0);OutputAttribute(ab);break;
                case  3:  ab=priorityTimesort(ab,0,0);OutputAttribute(ab);break;
            }
        }
        return ;
    }


    private static attribute[] Short_jobs_take_precedence(attribute[] ab,int i,int Begin) {
        int min_Run_time=-1;
        int min_input_time=i;
        int index=-1;
        //获取运行时间之前的运行时间最短的
        for (int j = Begin; j <ab.length ; j++) {
            if (ab[j].input_time<=i){
                if (min_Run_time==-1){
                    index=j;
                    min_Run_time=ab[j].Run_time;
                }else {
                    if(min_Run_time>ab[j].Run_time){
                        index=j;
                        min_Run_time=ab[j].Run_time;
                    }
                }
            }
        }
        if(index==-1){
            min_Run_time=ab[Begin].Run_time;
            min_input_time=ab[Begin].input_time;
            index=Begin;
            for (int j = Begin; j <ab.length ; j++) {
                if (ab[j].input_time<min_input_time){
                    min_input_time=ab[j].input_time;
                    index=j;
                    min_Run_time=ab[j].Run_time;
                }else {
                    if (ab[j].input_time==min_input_time){
                        if(min_Run_time<ab[j].Run_time){
                            min_input_time=ab[j].input_time;
                            index=j;
                            min_Run_time=ab[j].Run_time;
                        }
                    }
                }
            }
        }
        swat(ab,Begin,index);
        if (Begin+1==ab.length){
            return ab;
        }
        Short_jobs_take_precedence(ab,(Math.max(min_input_time, i))+min_Run_time,Begin+1);
        return ab;
    }
    public static void swat(attribute[] ab,int i, int index) {//交换位置
        attribute a=ab[i];
        ab[i]=ab[index];
        ab[index]=a;
    }
    private static attribute[] InputTimesort(attribute[] ab) {//到达时间排序
        for (int i=0;i<ab.length;i++){
            int min=i;
            for (int J=i;J<ab.length;J++){
                if(ab[J].getInput_time()<ab[i].getInput_time()){
                    min=J;
                }
            }
            swat(ab,i,min);
        }
        return ab;
    }
    private static attribute[] priorityTimesort(attribute[] ab,int i,int Begin) {//响应比排序
        int min_Run_time=-1;
        int min_input_time=i;
        int min_priority=0;
        int index=-1;
        //获取运行时间之前的优先级最高的
        for (int j = Begin; j <ab.length ; j++) {
            if (ab[j].input_time<=min_input_time){
                if (min_Run_time==-1){
                    index=j;
                    min_Run_time=ab[j].Run_time;
                    min_priority=(ab[j].input_time-i)/ab[j].Run_time;
                }else {
                    if(min_priority>(ab[j].input_time-i)/ab[j].Run_time){//优先级比我大
                        index=j;
                        min_Run_time=ab[j].Run_time;
                        min_priority=(ab[j].input_time-i)/ab[j].Run_time;
                    }
                }
            }
        }
        if(index==-1){
            min_Run_time=ab[Begin].Run_time;
            min_input_time=ab[Begin].input_time;
            index=Begin;
            for (int j = Begin; j <ab.length ; j++) {
                if (ab[j].input_time<min_input_time){//运行时间在我之前直接换
                    min_input_time=ab[j].input_time;
                    index=j;
                    min_Run_time=ab[j].Run_time;
                }else {
                    if (ab[j].input_time==min_input_time){
                        if(min_input_time<ab[j].Run_time){//运行时间小直接换
                            min_input_time=ab[j].input_time;
                            index=j;
                            min_Run_time=ab[j].Run_time;
                        }
                    }
                }
            }
        }
        swat(ab,Begin,index);
        if (Begin+1==ab.length){
            return ab;
        }
        priorityTimesort(ab,(Math.max(min_input_time, i))+min_Run_time,Begin+1);
        return ab;
    }
}
