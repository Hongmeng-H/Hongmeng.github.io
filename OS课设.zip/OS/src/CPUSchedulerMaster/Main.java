package CPUSchedulerMaster;

public class Main {
    public static void main(String[] args) {

        attribute[] ab = {
                new attribute(1, 5),
                new attribute(2, 5),
                new attribute(10, 5),
                new attribute(16, 15),
                new attribute(14, 25)};

        Master.runattribute(ab);
    }
}
