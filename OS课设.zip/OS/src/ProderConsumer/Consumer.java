package ProderConsumer;


import java.util.Random;

public class Consumer extends Thread{
    private int num;
    Consumer(int num)
    {
        this.num = num;
    }

    public void run() {
        try {
            synchronized(this) {
                Random random = new Random();
                wait(random.nextInt(400));
                ProderAndConsumer.insert1("消费者"+num+"打算消费");
                ProderAndConsumer.Con.add(num+"打算消费");

                ProderAndConsumer.Full.acquire();
                ProderAndConsumer.mutex.acquire();




                ProderAndConsumer.insert2("消费者"+num+"正在消费");

                ProderAndConsumer.Con.remove(num+"打算消费");
                ProderAndConsumer.ing.add("消费者"+num+"正在消费");
                wait(random.nextInt(5000)+1500);
                ProderAndConsumer.count--;
                ProderAndConsumer.insert2("消费者"+num+"结束消费");
                ProderAndConsumer.ing.remove("消费者"+num+"正在消费");
                ProderAndConsumer.insert1("消费者"+num+"完成消费");



                wait(3000);
                ProderAndConsumer.fresh.acquire();              //实现刷新页面时，线程的互斥
                ProderAndConsumer.refresh();                    //刷新页面，通过队列的信息刷新页面
                ProderAndConsumer.fresh.release();


                ProderAndConsumer.mutex.release();
                ProderAndConsumer.Empty.release();
            }

        } catch (InterruptedException e) {
            System.out.println("消费者"+num+"出现错误！");
            e.printStackTrace();
        }
    }

}