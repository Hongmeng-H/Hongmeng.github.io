package ProderConsumer;

import java.util.Random;

public class Proder extends Thread
{
    private int num;
    Proder(int num)
    {
        this.num = num;
    }

    public void run()
    {
        try
        {
            synchronized(this)
            {


                Random random = new Random();
                wait(random.nextInt(500));
                ProderAndConsumer.insert3("生产者"+num+"打算生产");
                ProderAndConsumer.Pro.add(num+"打算生产");

                ProderAndConsumer.Empty.acquire();
                ProderAndConsumer.mutex.acquire();

                ProderAndConsumer.insert2("生产者"+num+"正在生产");

                ProderAndConsumer.Pro.remove(num+"打算生产");
                ProderAndConsumer.ing.add("生产者"+num+"正在生产");
                wait(random.nextInt(10000)+3000);

                ProderAndConsumer.count++;
                ProderAndConsumer.insert2("生产者"+num+"结束生产");

                ProderAndConsumer.insert3("生产者"+num+"完成生产");
                ProderAndConsumer.ing.remove("生产者"+num+"正在生产");


                wait(3000);
                ProderAndConsumer.fresh.acquire();
                ProderAndConsumer.refresh();//刷新页面，通过队列的信息刷新页面
                ProderAndConsumer.fresh.release();

                ProderAndConsumer.mutex.release();
                ProderAndConsumer.Full.release();
            }
        } catch (InterruptedException e) {
            System.out.println("生产者"+num+"出现错误！");
            e.printStackTrace();
        }

    }
}
