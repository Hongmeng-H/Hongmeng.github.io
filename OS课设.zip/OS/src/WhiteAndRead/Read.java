package WhiteAndRead;

import java.util.Random;

public class Read extends Thread{
    private int num;
    Read(int num)
    {
        this.num = num;
    }

    public void run() {
        try {
            synchronized(this)
            {
                Random random = new Random();
                wait(random.nextInt(500));
                ReadAndWrite.insert1("读者"+num+"打算读文件");

                ReadAndWrite.Re.add(num+"打算读文件");

                ReadAndWrite.w.acquire();           //实现写优先
                ReadAndWrite.mutex.acquire();       //防止读者之间同步访问count，读者互斥访问count
                if(ReadAndWrite.count==0)
                    ReadAndWrite.rw.acquire();      //实现读写互斥
                ReadAndWrite.count++;               //我只要有东西正在读你，你就不许给我写东西，实现多读者同步的关键
                ReadAndWrite.mutex.release();
                ReadAndWrite.w.release();

                //以下为读文件的阶段
                ReadAndWrite.insert2("读者"+num+"正在读文件");
                ReadAndWrite.ing.add("读者"+num+"正在读文件");
                wait(random.nextInt(5000)+1500);
                ReadAndWrite.insert2("读者"+num+"结束读文件");
                ReadAndWrite.insert1("读者"+num+"完成读文件");
                ReadAndWrite.ing.remove("读者"+num+"正在读文件");
                ReadAndWrite.Re.remove(num+"打算读文件");
                //以上为读文件的阶段

                wait(3000);
                ReadAndWrite.fresh.acquire();              //实现刷新页面时，线程的互斥
                ReadAndWrite.refresh();                    //刷新页面，通过队列的信息刷新页面
                ReadAndWrite.fresh.release();

                ReadAndWrite.mutex.acquire();
                ReadAndWrite.count--;                   //文件读完了，读完一个出来一个，count--了
                if(ReadAndWrite.count==0)
                    ReadAndWrite.rw.release();
                ReadAndWrite.mutex.release();
            }

        } catch (InterruptedException e) {
            System.out.println("读者"+num+"出现错误！");
            e.printStackTrace();
        }
    }

}