package WhiteAndRead;

import java.util.Random;

public class Write extends Thread
{
    private int num;
    Write(int num)
    {
        this.num = num;
    }

    public void run()
    {
        try {
            synchronized(this) {
                Random random = new Random();
                wait(random.nextInt(500));
                ReadAndWrite.insert3("写者"+num+"打算写文件");
                ReadAndWrite.Wr.add(num+"打算写文件");
                ReadAndWrite.w.acquire();
                ReadAndWrite.rw.acquire();
                ReadAndWrite.insert2("写者"+num+"正在写文件");
                ReadAndWrite.ing.add("写者"+num+"正在写文件");
                wait(random.nextInt(10000)+3000);
                ReadAndWrite.insert2("写者"+num+"结束写文件");

                ReadAndWrite.insert3("写者"+num+"完成写文件");
                ReadAndWrite.ing.remove("写者"+num+"正在写文件");
                ReadAndWrite.Wr.remove(num+"打算写文件");

                wait(3000);
                ReadAndWrite.fresh.acquire();
                ReadAndWrite.refresh();//刷新页面，通过队列的信息刷新页面
                ReadAndWrite.fresh.release();

                ReadAndWrite.rw.release();
                ReadAndWrite.w.release();
            }
        } catch (InterruptedException e) {
            System.out.println("写者"+num+"出现错误！");
            e.printStackTrace();
        }

    }
}
