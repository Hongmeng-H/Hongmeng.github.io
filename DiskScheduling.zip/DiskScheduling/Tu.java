package DiskScheduling;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;

import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;
import javax.swing.*;
import java.awt.*;

import static DiskScheduling.GUI.createDataset;


public class Tu extends ApplicationFrame {

    private static final long serialVersionUID = -6354350604313079793L;
    /* synthetic */static Class class$demo$LineChartDemo1;
    public Tu(String string) {
        super(string);
        JPanel jpanel = createDemoPanel();
        jpanel.setPreferredSize(new Dimension(500, 300));
        setContentPane(jpanel);
    }


    public static JPanel createDemoPanel() {
        JFreeChart jfreechart = createChart(createDataset());
        return new ChartPanel(jfreechart);
    }

    private static JFreeChart createChart(XYDataset createDataset) {
        JFreeChart jfreechart = ChartFactory.createXYLineChart(
                "DiskScheduling", // chart title
                "磁道", // x axis label
                "", // y axis label
                createDataset(), // data
                PlotOrientation.HORIZONTAL,
                true, // include legend
                true, // tooltips
                false // urls
        );

        jfreechart.setBackgroundPaint(Color.white);
        XYPlot xyplot = (XYPlot) jfreechart.getPlot();
        xyplot.setBackgroundPaint(Color.lightGray);
        xyplot.setAxisOffset(new RectangleInsets(5.0, 5.0, 5.0, 5.0));
        xyplot.setDomainGridlinePaint(Color.white);
        xyplot.setRangeGridlinePaint(Color.white);
        XYLineAndShapeRenderer xylineandshaperenderer = (XYLineAndShapeRenderer) xyplot.getRenderer();
        xylineandshaperenderer.setShapesVisible(true);
        xylineandshaperenderer.setShapesFilled(true);
        NumberAxis numberaxis = (NumberAxis) xyplot.getRangeAxis();
        numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        return jfreechart;
    }



    /* synthetic */
    static Class class$(String string) {
        Class var_class;
        try {
            var_class = Class.forName(string);
        } catch (ClassNotFoundException classnotfoundexception) {
            throw new NoClassDefFoundError(classnotfoundexception.getMessage());
        }
        return var_class;
    }

    public static void main(String[] args) {
        Tu tu= new Tu(
                "磁盘调度图");
        tu.pack();
        RefineryUtilities.centerFrameOnScreen(tu);
        tu.setVisible(true);


    }
}
