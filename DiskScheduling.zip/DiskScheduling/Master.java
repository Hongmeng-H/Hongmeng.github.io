package DiskScheduling;

import java.util.Arrays;

public class Master {
	static int[] a;
	static Integer direction;
	static String master;
	static int first;
	Master(int a[],String master,int first,String direction){
		Master.a = a;

		Master.first = first;
		Master.master = master;
		if (direction.equals("磁道序号增加")){
			Master.direction = 1;
		}else {
			Master.direction = 0;
		}

	}


	/**
	 * 改进的二分查找
	 * @param nums	查找数组
	 * @param target	值
	 * @return		返回最近元素下标
	 */
	public static int serchInsert(int[] nums,int target) {
		int i = 0,j = nums.length-1;
		int mid = 0;
		if(target<nums[0]) return 0;
		if(target>nums[j]) return nums.length-1;
		while(i<=j) {
			mid = (i+j)/2;
			if(target>nums[mid]) i = mid+1;
			if(target<nums[mid]) j = mid-1;
			if(target == nums[mid]) return mid;
		}
		if(i-1<0) return i;
		if(Math.abs(nums[i-1]-target)>Math.abs(nums[i]-target)) return i;
		else return i-1;
	}




	static int[] FCFS(int a[]) {
		return a;
	}

	static int[] SSTF(int a[],int index){
		if (a[index]==a[0]){
			//不做变化

		}else if (a[index]==a[a.length-1]){
			//数组对调
			for (int start = 0, end = a.length - 1; start < end; start++, end--) {
				int temp = a[end];
				a[end] = a[start];
				a[start] = temp;
			}

		}else {
			//int c[a.length-1];
			int []c = Arrays.copyOf(a,a.length);		//数组复制，不能直接复制！！！
			a[0] = c[index];
			int left=index-1,right=index+1;		//左右指针

			for (int i = 1; i < a.length;i++) {

				if ((c[index] - c[left]) > (c[right] - c[index])) {            //index右移一位

					if (c[right] < c[c.length - 1]) {

						a[i] = c[right];
						index = right;
						right++;
					} else {
						a[i] = c[c.length - 1];                //到右端点又变成SCAN
						for (int k = 1; c[left] > c[0]; k++) {
							a[i + k] = c[left];
							left--;
						}
						break;
					}

				} else {
					if (c[left] > c[0]) {
						a[i] = c[left];
						index = left;
						left--;
					}else{
							a[i] = c[0];                //到左端点又变成SCAN
							for (int k = 1; c[right] < c[c.length - 1]; k++) {
								a[i + k] = c[right];
								right++;
							}
							break;
						}
					}
				}

			}
		return a;
	}


	static int[] SCAN(int a[],int index,int direction){
		//实际上为LOOK算法
		if (a[index]==a[0]){
			//不做变化

		}else if (a[index]==a[a.length-1]){
			//数组对调
			for (int start = 0, end = a.length - 1; start < end; start++, end--) {
				int temp = a[end];
				a[end] = a[start];
				a[start] = temp;
			}

		}else {

			int[] c = Arrays.copyOf(a, a.length);        //数组复制，不能直接复制！！！
			//a[0] = c[index];
			int start=0;
			if (direction == 0){	//减少  <-


				//需要与first比较!
				if (first>c[index]){

					for (int k=index;k>=0;k--){
						a[start] = c[k];
						start++;
					}
					for (int end=index+1;end<c.length;end++,start++){
						a[start] = c[end];
					}
				}else {
					for (int k=index-1;k>=0;k--){
						a[start] = c[k];
						start++;
					}
					for (int end=index;end<c.length;end++,start++){
						a[start] = c[end];
					}
				}


			}else {					//增加  ->
//				int start=1;
//				for (int end=index+1;end<c.length;end++,start++){
//					a[start] = c[end];
//
//					}
//				//start++;
//				for (int k=index-1;k>=0;k--){
//
//					a[start] = c[k];
//					start++;
//				}

				//需要与first比较!
				if (first>c[index]){

					for (int end=index+1;end<c.length;end++,start++){
						a[start] = c[end];
					}
					for (int k=index;k>=0;k--){
						a[start] = c[k];
						start++;
					}
				}else {
					for (int end=index;end<c.length;end++,start++){
					a[start] = c[end];
					}
					for (int k=index-1;k>=0;k--){
						a[start] = c[k];
						start++;
					}
				}
			}
		}
		return a;
	}

	static int avg_seek_length(int a[]){		//寻道长度
		int length = 0;
		for (int one=0,two=1;one<a.length-1;one++,two++){
			length+=Math.abs(a[two]-a[one]) ;	//取绝对长度
		}
		return length;
	}

	static int[] toucha(int first,int a[]){			//头插元素
		int []b = new int[a.length+1];
		b[0] = first;
		System.arraycopy(a, 0, b, 1, a.length);
		return b;
	}

	static int[][]	Coordinate2D(int []a){
		int Y = 5;
		int[][] arr	= new int[a.length][2];
		for (int i=0;i<a.length;i++){
			for (int j=0;j<2;j++){
				if (j==0) {
					arr[i][j] = Y*i;
				}else {
					arr[i][j] =	a[i];
				}
			}
		}
		return arr;
	}

//	public static void main(String[] args) {
//		int[] a0 = Arrays.copyOf(a, a.length);
//		//对a冒泡排序
//		int b[] = a;
//
//		for(int i = 0; i < b.length-1 ; i++){
//			for(int j = 0; j < b.length-1-i; j++)
//				if (b[j] > b[j+1]){
//					int tmp = a[j];
//					b[j] = b[j+1];
//					b[j+1] = tmp;
//				}
//
//		}
//
//
//		int index =  serchInsert(a,first) ;	//二分查找获取下标
//
//		if (master.equals("先来先服务算法")){
//			int c[] = toucha(first,FCFS(a0));		//头部插入定义的磁道数
//
//			for(int element: c) {
//				System.out.println(element);
//			}
//
//
//			System.out.println("扫描算法平均寻道长度："+avg_seek_length(c));
//			System.out.println("平均寻道长度："+avg_seek_length(c)*1.0/(c.length-1));
//		}else if (master.equals("最短寻道时间优先算法")){
//
//			int c[] = toucha(first,SSTF(b,index));		//头部插入定义的磁道数
//
//			for(int element: c) {
//				System.out.println(element);
//			}
//			System.out.println("扫描算法平均寻道长度："+avg_seek_length(c));
//			System.out.println("平均寻道长度："+avg_seek_length(c)*1.0/(c.length-1));
//		}else if (master.equals("扫描算法")){
//			int c[] = toucha(first,SCAN(b,index,direction));		//头部插入定义的磁道数
//
//			for(int element: c) {
//				System.out.println(element);
//			}
//			System.out.println("扫描算法平均寻道长度："+avg_seek_length(c));
//			System.out.println("平均寻道长度："+avg_seek_length(c)*1.0/(c.length-1));
//		}else {
//			FCFS(a);
//			SSTF(a,index);
//			SCAN(a,index,direction);
//		}
//	}
}
