package DiskScheduling;

import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import java.awt.*;
import java.util.Arrays;
import java.util.Objects;

import javax.swing.*;

import static DiskScheduling.Master.*;

public class GUI extends JDialog {
    static JTextField jtf1;
    static JTextField jtf3;
    static JComboBox<String> jb1,jb2;   //两个复选框

    static XYSeries xyseries = new XYSeries("Master");

    public GUI() {
        setTitle("磁盘调度");
        setModal(true);
        setSize(350, 300);//对话框的大小
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);//关闭后销毁对话框
        setLocationRelativeTo(null);
        JLabel jl1 = new JLabel("   请输入磁道访问序列(空格间隔，范围0~200,不重复)  :");
        jtf1 = new JTextField(30);
        jtf1 .setPreferredSize(new Dimension(350,40));
        JLabel jl2 = new JLabel("请选择调度算法:");
        jb1 = new JComboBox<>();
        JLabel jl3 = new JLabel("请指定磁头起始位置:");
        jtf3 = new JTextField(8);
        JLabel jl4 = new JLabel("请指定磁头移动方向:");
        jb2 = new JComboBox<>();
        //JPanel jp = new JPanel(new GridLayout(1, 1));
       JPanel jp = new JPanel(new FlowLayout());
        jp.add(jl1);
        jp.add(jtf1);
        jp.add(jl2);
        jp.add(jb1);
        jp.add(jl3);
        jp.add(jtf3);
        jp.add(jl4);

        jb1.addItem("先来先服务算法");
        jb1.addItem("最短寻道时间优先算法");
        jb1.addItem("扫描算法");
        jb1.addItem("所有算法比较");

        jb2.addItem("磁道序号增加");
        jb2.addItem("磁道序号减少");


        jp.add(jb2);

        JButton jb = new JButton("确认输入");
        //newArray = str.split("\\s");   //（以多个空白字符分隔，若无+，则以单个空白字符分隔）
        jb.addActionListener(e -> {
            JComponent comp = (JComponent) e.getSource();
            Window win = SwingUtilities.getWindowAncestor(comp);
            win.dispose();
            //Tu.sou();
        });

        add(jp);

        add(jb,BorderLayout.SOUTH);

    }

    /**
     * 数据集
     */
     static XYDataset createDataset() {



//        xyseries.add(1.0, 1.0);
//        xyseries.add(2.0, 4.0);
//        xyseries.add(3.0, 3.0);
//        xyseries.add(4.0, 5.0);
//        xyseries.add(5.0, 5.0);
//        xyseries.add(6.0, 7.0);
//        xyseries.add(7.0, 7.0);
//        xyseries.add(8.0, 8.0);
        XYSeriesCollection xyseriescollection = new XYSeriesCollection();
        xyseriescollection.addSeries(xyseries);
        return xyseriescollection;
    }

    public static void main(String[] args) {
        new GUI().setVisible(true);
        String[] digitWord = jtf1.getText().split("\\D+");
        int[] a = new int[digitWord.length];
        for( int i=0;i<digitWord.length;i++ ){
            a [i] = Integer.parseInt(digitWord[i]);
        }
        String master = (String) jb1.getSelectedItem();
        int first = Integer.parseInt(jtf3.getText());
        String direction = (String) jb2.getSelectedItem();
        assert direction != null;
        new Master(a,master,first,direction);
        //Master.main(args);

        int [][]d;     //二维数组





        /*
          原Master
         */
        int[] a0 = Arrays.copyOf(a, a.length);
        //对a冒泡排序

        for(int i = 0; i < a.length-1 ; i++){
            for(int j = 0; j < a.length-1-i; j++)
                if (a[j] > a[j+1]){
                    int tmp = a[j];
                    a[j] = a[j+1];
                    a[j+1] = tmp;
                }

        }


        int index =  serchInsert(a,first) ;	//二分查找获取下标

        switch (Objects.requireNonNull(master)) {
            case "先来先服务算法": {
                int[] c = toucha(first, FCFS(a0));        //头部插入定义的磁道数


                for (int element : c) {
                    System.out.println(element);
                }
                System.out.println("扫描算法平均寻道长度：" + avg_seek_length(c));
                System.out.println("平均寻道长度：" + avg_seek_length(c) * 1.0 / (c.length - 1));


                d = Coordinate2D(c);
                createDataset();
                for (int[] X :
                        d) {
                    xyseries.add(X[0], X[1]);
                }


                break;
            }
            case "最短寻道时间优先算法": {

                int[] c = toucha(first, SSTF(a, index));        //头部插入定义的磁道数


                for (int element : c) {
                    System.out.println(element);
                }
                System.out.println("扫描算法平均寻道长度：" + avg_seek_length(c));
                System.out.println("平均寻道长度：" + avg_seek_length(c) * 1.0 / (c.length - 1));

                d = Coordinate2D(c);
                createDataset();
                for (int[] X :
                        d) {
                    xyseries.add(X[0], X[1]);
                }

                break;
            }
            case "扫描算法": {
                int[] c = toucha(first, SCAN(a, index, Master.direction));        //头部插入定义的磁道数


                for (int element : c) {
                    System.out.println(element);
                }
                System.out.println("扫描算法平均寻道长度：" + avg_seek_length(c));
                System.out.println("平均寻道长度：" + avg_seek_length(c) * 1.0 / (c.length - 1));


                d = Coordinate2D(c);
                createDataset();
                for (int[] X :
                        d) {
                    xyseries.add(X[0], X[1]);
                }
                System.out.println(xyseries);
                break;
            }
            default:
                FCFS(a);
                SSTF(a, index);
                SCAN(a, index, Master.direction);
                break;
        }
        
        Tu.main(args);
        
        
    }
}